<h1>Team</h1>

<h2>Project leaders</h2>

<ul>
	<li><a href="http://w3.umons.ac.be/staff/Mens.Tom">Tom Mens</a>, <a href="http://informatique.umons.ac.be/genlog/">Software Engineering Lab</a>, <a href="https://portail.umons.ac.be/FR/Pages/default.aspx">Université de Mons</a></li>
	<li><a href="http://directory.unamur.be/staff/acleve">Anthony Cleve</a>, <a href="http://www.unamur.be/en/precise/">PReCISE research center</a>, <a href="http://www.unamur.be/">Université de Namur</a>
</ul>

<h2>PhD Students</h2>

<ul>
	<li><a href="http://directory.unamur.be/staff/lmeurice?_LOCALE_=en">Loup Meurice</a>, <a href="http://www.unamur.be">Université de Namur</a>
</ul>

<h2>Postdocs</h2>

<ul>
	<li><a href="http://w3.umons.ac.be/staff/Goeminne.Mathieu/">Mathieu Goeminne</a>, <a href="http://informatique.umons.ac.be/genlog/">Software Engineering Lab</a>, <a href="https://portail.umons.ac.be/FR/Pages/default.aspx">Université de Mons</a></li>
</ul>

<h2>Collaborator</h2>

<ul>
	<li><a href="http://decan.lexpage.net/">Alexandre Decan</a>, <a href="http://informatique.umons.ac.be/ssi/">Service des Systèmes d'Information</a>, <a href="https://portail.umons.ac.be/FR/Pages/default.aspx">Université de Mons</a></li>	
</ul>