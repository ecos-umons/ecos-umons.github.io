<h1>Events</h1>


<h2>2014</h2>

<ul>
	<li><a href="http://ansymo.ua.ac.be/csmr-wcre/venue">CSMR-WCRE 2014</a></li>
</ul>

<h2>2013</h2>

<ul>
	<li><a href="http://informatique.umons.ac.be/genlog/benevol2013/">BENEVOL 2013</a></li>
</ul>